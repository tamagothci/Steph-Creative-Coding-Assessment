let angle = 0;

function setup() {
	createCanvas(800, 800);
	background(226, 255, 110);
	angleMode(DEGREES); //changing math to degrees from radians
}

function draw() {
	//background(226, 255, 110);

	push();
	translate(width / 4, height / 4)
	rotate(angle);
	fill(237, 255, 166, 10);
	stroke(247, 57, 143);
	strokeWeight(.5);
	ellipse(100, 0, 100, 100);
	pop();

	push();
		translate(width*0.5, height/4)
		rotate(-angle);
		fill(237, 255, 166, 10);
		stroke(110, 216, 255);
		strokeWeight(.5);
		ellipse(100, 0, 100, 100);
	pop();
	
	push();
		translate(width*0.75, height/4)
		rotate(angle);
		fill(237, 255, 166, 10);
		stroke(247, 57, 143);
		strokeWeight(.5);
		ellipse(100, 0, 100, 100);
	pop();
	
	//second line
	push();
		translate(width/4, height/2)
		rotate(-angle);
		fill(237, 255, 166, 10);
		stroke(110, 216, 255);
		strokeWeight(.5);
		ellipse(100, 0, 100, 100);
	pop();

	push();
		translate(width/2, height/2)
		rotate(angle);
		fill(237, 255, 166, 10);
		stroke(247, 57, 143);
		strokeWeight(.5);
		ellipse(100, 0, 100, 100);
	pop();
	
	push();
		translate(width*0.75, height/2)
		rotate(-angle);
		fill(237, 255, 166, 10);
		stroke(110, 216, 255);
		strokeWeight(.5);
		ellipse(100, 0, 100, 100);
	pop();
	
	//third line
	push();
		translate(width/4, height*0.75)
		rotate(angle);
		fill(237, 255, 166, 10);
		stroke(247, 57, 143);
		strokeWeight(.5);
		ellipse(100, 0, 100, 100);
	pop();

	push();
		translate(width/2, height*0.75)
		rotate(-angle);
		fill(237, 255, 166, 10);
		stroke(110, 216, 255);
		strokeWeight(.5);
		ellipse(100, 0, 100, 100);
	pop();
	
	push();
		translate(width*0.75, height*0.75)
		rotate(angle);
		fill(237, 255, 166, 10);
		stroke(247, 57, 143);
		strokeWeight(.5);
		ellipse(100, 0, 100, 100);
	pop();

	angle++
	
	//222, 164, 252 purple
	//255, 252, 77 yellow
}