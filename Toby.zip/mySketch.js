function setup() {
	//make a canvas by a specific pixel size and colour
	createCanvas(500, 500);
	background('#B3DF8C');
}

//the newest function is applied over the previous

function draw() {
	//fills the shape below with a colour 0-244 black-white and r,g,b for colours
	fill (86);
	// draws a circle or ellipse
	ellipse(width/2, height/2, 250, 250);
	
	
	//draws a triangle
	//first 2 numbers are where the first point is, 3rd and 4th are the second point and 5th and 6th is the 3rd point
	//left ear
	triangle(135, 200, 200, 135, 135, 80);
	//right ear
  triangle(365, 200, 365, 80, 300, 135);
	
	// irises
	fill('#B3DF8C');
	ellipse(300, 250, 50);
	ellipse(200, 250, 50);
	
	//pupils
	fill(0);
	ellipse(300, 250, 40);
	ellipse(200, 250, 40);
	
	//nose
	fill(50);
	ellipse(250, 280, 30, 10);
	
	//inside of ears
	//left ear
	fill(223, 156,156);
	triangle(150, 185, 185, 150, 150, 120);
	//right ear
	triangle(350, 185, 315, 150, 350, 120);
	
}