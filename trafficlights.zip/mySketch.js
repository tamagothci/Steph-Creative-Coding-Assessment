function setup() {
	createCanvas(1000, 1000);

}

function draw() {
	background(166, 213, 227);
	
	fill(70);
	rect(500, 850, 1000, 300);
	
	fill(230);
	rect(500, 800, 1000, 30);

	//position of the rectangle (AI helped me here bc I couldn't work out why it
	//wasn't working turns our I just needed to insert 'let')
	let x = mouseX;
	let y = mouseY;
	
	//draws rectangles from its centre
	rectMode(CENTER);

	//fills the rectangle black
	fill(0);
	//draw the rectangle at the coordinates with a radius for curved corners
	rect(x, y, 100, 60, 15);

	//fills the traffic light base
	fill(100);
	noStroke();
	//draws traffic lights with radius of 10
	rect(800, 200, 150, 350, 10);
	
	//draws red light
	if(mouseX>666){
		fill(250, 0, 21);
	} else {fill(125, 19, 28);
				 }
	noStroke();
	ellipse(800, 90, 90);
	
	
	//draws yellow light
	//&& is used because >333 and <=666 are both true
	// AI helped for && because I was trying to us || which means or)
	if(mouseX>333 && mouseX<=666){
		fill(255, 196, 3);
	} else {fill(138, 103, 18);
				 }
	noStroke();
	ellipse(800, 200, 90);
	
	//draws green light
	if(mouseX<333){
		fill(7, 240, 27);
	} else {fill(17, 112, 25);
				 }
	noStroke();
	ellipse(800, 310, 90);
	
	}
	
